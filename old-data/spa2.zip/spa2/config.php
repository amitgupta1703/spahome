<?php 

//$db = mysqli_connect('localhost:3306', 'root', 'shiv', 'spa');  
$db = mysqli_connect('localhost:3306', 'u231784203_spadbun', '0Z^Bj:^Z3=Wk', 'u231784203_spadb');  
?>