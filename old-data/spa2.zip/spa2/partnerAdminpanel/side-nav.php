<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
  <div class="menu_section">

    <ul class="nav side-menu">
      <li>
        <a href="dashboard.php">
          <i class="fa fa-dashboard"></i> Dashboard
        </a>
      </li>

      <li><a href="check-appointments.php"><i class="fa fa-edit"></i> Check Appointments</a>
          
      </li>
      <li>
        <a href="change-password.php">
          <i class="fa fa-users"></i> Change Password
        </a>
      </li>
      <li><a><i class="fa fa-edit"></i> Services <span class="fa fa-chevron-down"></span></a>
          <ul class="nav child_menu">
              <li><a href="post-services.php">Add New Service</a></li>
              <li><a href="all-posted-services.php">All Services</a></li>
              
          </ul>
      </li>
      
	
       
    </ul>
  </div>


</div>