<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
  <div class="menu_section">

    <ul class="nav side-menu">
      <li>
        <a href="dashboard.php">
          <i class="fa fa-dashboard"></i> Dashboard
        </a>
      </li>
      <li><a href="book-appointment-data.php">
      <i class="fa fa-file-o"></i> Appointment Booked
      </a></li>
     <!--  <li>
        <a href="register-partners.php">
          <i class="fa fa-user"></i> Register Partners
        </a>
      </li> -->
      <li><a href="all-user-contact.php">
      <i class="fa fa-group"></i> Contact Users
      </a></li>
      <li><a><i class="fa fa-edit"></i> Partners <span class="fa fa-chevron-down"></span></a>
          <ul class="nav child_menu">
              <li><a href="register-partners.php">  <i class="fa fa-user"></i> Register Partners </a></li>
              <li><a href="generate-partners-credentials.php"><i class="fa fa-lock"></i> Generate Partners Credentials</a></li>
              <li><a href="all-partners-credentials.php"><i class="fa fa-lock"></i> All Partners Credentials</a></li>
              
          </ul>
      </li>
      
	
       
    </ul>
  </div>


</div>